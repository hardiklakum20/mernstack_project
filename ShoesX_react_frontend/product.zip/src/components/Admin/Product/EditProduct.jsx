import React from 'react'
import '../../Assets/scss/product.css'

function EditProduct() {
    return (
        <>
            <div className='add-product-head'>
                <h3>Edit Product</h3>
            </div>
            <div className='add-product-body body-bg'>
                <div className="row">
                    <div className="col-md-6">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name:</label>
                            <input type="text" class="form-control" id="name" placeholder="Enter Name" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div class="mb-3">
                            <label for="description" class="form-label">Description:</label>
                            <input type="text" class="form-control" id="description" placeholder="Enter Description" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div class="mb-3">
                            <label for="category-add" class="form-label">Category:</label>
                            <input type="text" class="form-control" id="category-add" placeholder="Enter Category" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div class="mb-3">
                            <label for="brand" class="form-label">Brand:</label>
                            <input type="text" class="form-control" id="brand" placeholder="Brand" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div class="mb-3">
                            <label for="sku" class="form-label">Sku:</label>
                            <input type="text" class="form-control" id="sku" placeholder="Enter Sku" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div class="mb-3">
                            <label for="Material" class="form-label">Material</label>
                            <input type="text" class="form-control" id="Material" placeholder="Material" />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="product-image" class="form-label">Product Images:</label>
                            <input type="file" class="form-control" id="product-image" />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <label for="variants" class="form-label">Variants:</label>
                    </div>
                    <div className="col-lg-4 col-md-6">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="color" placeholder='Color' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="size" placeholder='Size' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="Price" placeholder='Price' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="discount" placeholder='Discount' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="stock" placeholder='Stock' />
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="color" placeholder='Color' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="size" placeholder='Size' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="Price" placeholder='Price' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="discount" placeholder='Discount' />
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="stock" placeholder='Stock' />
                        </div>
                    </div>                                        
                    <div className="row d-flex justify-content-end ">
                        <div className="col-md-6 d-flex justify-content-end">
                            <button className='btn btn-dark'>Submit</button>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
}

export default EditProduct