import React from 'react'
import '../../Assets/scss/product.css'
import { Link } from 'react-router-dom'

function Product() {
    return (
        <>
            <div className='product-head'>
                <h3>Product</h3>
                <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link>
            </div>
            <div className='product-body body-bg'>
                <input placeholder="Search Product" type="text" />
                <div className='product-table table-responsive-xxl'>                
                    <table class="table">
                        <thead className='table-secondary'>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Size</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>1</th>
                                <td>Bata</td>
                                <td>Blazer made of 100% suede leather.</td>
                                <td>Men</td>
                                <td>Bata</td>
                                <td>1500</td>
                                <td>20</td>
                                <td>8</td>
                                <td>
                                    <div className='action'>
                                       <Link to={"/admin/product/view-product"} className='text-black'><i class="fa-solid fa-eye"></i></Link>
                                       <Link to={"/admin/product/edit-product"} className='text-black'> <i class="fa-solid fa-pen-to-square"></i></Link>
                                        <i class="fa-solid fa-trash"></i>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>2</th>
                                <td>Bata</td>
                                <td>Blazer made of 100% suede leather.</td>
                                <td>Men</td>
                                <td>Bata</td>
                                <td>1500</td>
                                <td>20</td>
                                <td>8</td>
                                <td>
                                    <div className='action'>
                                        <i class="fa-solid fa-eye"></i>
                                        <i class="fa-solid fa-pen-to-square"></i>
                                        <i class="fa-solid fa-trash"></i>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>3</th>
                                <td>Bata</td>
                                <td>Blazer made of 100% suede leather.</td>
                                <td>Men</td>
                                <td>Bata</td>
                                <td>1500</td>
                                <td>20</td>
                                <td>8</td>
                                <td>
                                    <div className='action'>
                                        <i class="fa-solid fa-eye"></i>
                                        <i class="fa-solid fa-pen-to-square"></i>
                                        <i class="fa-solid fa-trash"></i>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </>
    )
}

export default Product