import React from 'react'
import ProductOne from '../../Assets/Images/product-img-1.jpg'
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';

function ViewProduct() {
    return (
        <>
            <div className='view-product-head'>
                <h3>View Product</h3>
            </div>
            <div className='view-product-body body-bg'>
                <div className="row">
                    <div className="col-lg-6 col-md-12">
                        <img src={ProductOne} alt="product" className='img-fluid' />
                        <div className='img-child'>
                        <Swiper
                            slidesPerView={5}
                            spaceBetween={20}
                            className="mySwiper"
                            breakpoints={
                                {
                                    1024: {
                                        slidesPerView: 4,
                                        spaceBetween: 15,
                                    },
                                    768: {
                                        slidesPerView: 4,
                                        spaceBetween: 10,
                                    },                                    
                                    425: {
                                        slidesPerView: 3,
                                        spaceBetween: 10,
                                    },                                    
                                    375: {
                                        slidesPerView: 2,
                                        spaceBetween: 10,
                                    },                                    
                                    320: {
                                        slidesPerView: 2,
                                        spaceBetween: 10,
                                    },                                    
                                }
                            }
                        >
                            <SwiperSlide>
                                <img src={ProductOne} alt="product" className='img-fluid' />

                            </SwiperSlide>
                            <SwiperSlide>
                                <img src={ProductOne} alt="product" className='img-fluid' />

                            </SwiperSlide>
                            <SwiperSlide>
                                <img src={ProductOne} alt="product" className='img-fluid' />

                            </SwiperSlide>
                            <SwiperSlide>
                                <img src={ProductOne} alt="product" className='img-fluid' />

                            </SwiperSlide>
                            <SwiperSlide>
                                <img src={ProductOne} alt="product" className='img-fluid' />

                            </SwiperSlide>                            
                        </Swiper>
                        

                        </div>
                    </div>
                    <div className="col-lg-6 col-md-12">
                        <h4>SUEDE BLAZER</h4>
                        <p>Blazer made of 100% suede leather. Featuring a lapel collar, long sleeves, front flap pockets, matching lining and a back vent. Button fastening at the front.</p>
                        <p>Category:- Woman</p>
                        <p>Brand:- Zara</p>
                        <div className='price-content'>
                            <h3>13501</h3>
                            <p><del>15500</del></p>
                            <p className='discount'>13% OFF</p>
                        </div>
                        <div className='color-content'>
                            <h6>Color:-</h6>
                            <span></span>
                            <span></span>
                        </div>
                        <div className='size-content'>
                            <h6>Size:-</h6>
                            <p>S,M,L</p>
                        </div>
                        <div className='sku-content'>
                            <h6>SKU:- </h6>
                            <p>bata</p>
                        </div>
                        <div className='sku-content'>
                            <h6>Material:-</h6>
                            <p>100% polyester</p>
                        </div>
                        <div className='sku-content'>
                            <h6>Stock:-</h6>
                            <p>20</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ViewProduct