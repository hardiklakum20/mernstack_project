

export function User(){

    return(
        <div>
            hello how are you
        </div>
    )
}