import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import loginData from './data.js'; // Import login data
import '../../Assets/scss/Login.css';

export function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = () => {
        const user = loginData.find(user => user.Username === username && user.Password === password);
        
        if (user) {
            navigate('/admin/dashboard');
        } else {
            setError('Invalid username or password');
        }
    };

    return (
       <div className='d-flex'>
            <div className='login-side'>
                <div className='container'>
                    <div>
                        <p className='login-title'>Welcome to <br/>ShoesX</p>
                        <p className='login-txt'>
                            Discover a world of style, comfort, and performance with ShoesX.
                            From casual sneakers to elegant formal wear and high-performance sports shoes, 
                            we have the perfect pair for every occasion. Step up your shoe game with ShoesX!
                        </p>
                        <button className='learn-more-btn'>Learn More</button>
                    </div>
                </div>
            </div>
            <div className='login-main'>
                <div className='container d-flex justify-content-center align-items-center'>
                    <div>
                        <p className='login-type'>Username</p>
                        <input 
                            type='text' 
                            className='input-type' 
                            value={username} 
                            onChange={(e) => setUsername(e.target.value)}
                        />
                        <p className='login-type mt-3'>Password</p>
                        <input 
                            type='password' 
                            className='input-type' 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        {error && <p className='error-text'>{error}</p>}
                        <p className='forgot-password'>Forgot Password<span className='bi bi-question'></span></p>
                        <button className='signin-btn' onClick={handleLogin}>Sign in</button>
                    </div>
                </div>
            </div>
       </div>
    );
}
