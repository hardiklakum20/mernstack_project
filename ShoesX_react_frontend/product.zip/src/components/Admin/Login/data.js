
const login = [
    {
        Username : 'admin',
        Password : 'admin@123'
    },
    {
        Username : 'user',
        Password : 'user@123'
    }
]

export default login;