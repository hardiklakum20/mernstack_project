import '../../Assets/scss/category.css';

export function Category(){

    return(
        <>
          <div className='d-flex justify-content-between'>
            <p id='category'>Category</p>  
            <button id='add-category-btn'>Add Category</button>
          </div>

          <div className='categroy-description'>
            <div>
                <input type='text' placeholder='Search Category' className='search-bar'/>
            </div>
            <table class="table  table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Puma</td>
                        <td>
                            <button className="btn btn-outline-success">Edit</button>
                            <button className='btn btn-outline-danger ms-2'>Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
          </div>
        </>
    )
}