import '../../Assets/scss/dashboard.css';
import dash_img from '../../Assets/Images/dash_img.png';
import dash2 from '../../Assets/Images/dash2.svg';
import dash3 from '../../Assets/Images/dash3.svg';
import dash4 from '../../Assets/Images/dash4.svg';
import dash5 from '../../Assets/Images/dash5.svg';
import React, { useState } from 'react';
import ReactApexChart from 'react-apexcharts';
import list from '../../Assets/Images/list.svg'

export function Dashboard(){

    const [state, setState] = useState({
        series: [{
            name: "Desktops",
            data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
        }],
        options: {
            chart: {
                height: 350,
                type: 'line',
                zoom: {
                    enabled: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'straight'
            },
            grid: {
                row: {
                    colors: ['#f3f3f3', 'transparent'],
                    opacity: 0.5
                },
            },
            xaxis: {
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
            }
        }
    });

    const donutSeries = [50, 35, 21, 17, 15];

    const donutOptions = {
        chart: {
            type: "donut",
        },
        plotOptions: {
            pie: {
                startAngle: -90,
                endAngle: 90,
                offsetY: 10,
            },
        },
        grid: {
            padding: {
                bottom: -100,
            },
        },
        responsive: [
            {
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200,
                    },
                    legend: {
                        position: "bottom",
                    },
                },
            },
        ],
    };

    return(
        <div>
            <div className="d-flex mt-5">
                <div className="dash1 d-flex">
                   <div className='ps-4 pt-3'>
                    <p className='title'>Welcome Jonathan Deo</p>
                        <p className='txt'>Check all the statastics</p>
                        <div className='d-flex mt-3'>
                            <div className='dash1-sec-bg'>
                                <p className='txt1'>573</p>
                                <p className='txt2'>Leads</p>
                            </div>
                            <div className='dash2-sec-bg'>
                                <p className='txt1'>87%</p>
                                <p className='txt2'>Conversion</p>
                            </div>
                        </div>
                   </div>
                   <div>
                        <img src={dash_img} className='dash_img'></img>
                    </div>
                </div>

                <div className='dash2'>
                    <div className='img-bg'>
                        <img src={dash2}></img>
                    </div>
                    <p className='number'>2358 <span>+23%</span></p>
                    <p className='txt'>Sales</p>
                </div>

                <div className='dash3'>
                    <div className='img-bg'>
                        <img src={dash3}></img>
                    </div>
                    <p className='number'>434 <span>-12%</span></p>
                    <p className='txt'>Refunds</p>
                </div>

                <div className='dash4'>
                    <div className='img-bg'>
                            <img src={dash4}></img>
                        </div>
                        <p className='number'>$245k <span>+8%%</span></p>
                        <p className='txt'>Earnings</p>
                    </div>
            </div>

            <div className='dash-grid'>
                <div className='dash-grid1'>
                    <div className='d-flex justify-content-between me-3'>
                        <p className='dash-title'>Sales Profit</p>
                        <div className='dash-btn-bg d-flex'>
                            <div className='profit-bg'>Profit</div>
                            <p>Expenses</p>
                        </div>
                    </div>
                    <div id="chart">
                        <ReactApexChart options={state.options} series={state.series} type="line" height={350} />
                    </div>
                    <div id="html-dist"></div>
                    <div className='d-flex justify-content-between mt-4'>
                        <div className='d-flex'>
                            <div className='d-flex'>
                                <div className='svg-bg'>
                                    <img src={list} width='100%' height='25px'></img>
                                </div>
                                <div className='ms-3'>
                                    <p className='profit'>$63,489.50</p>
                                    <p className='profit-txt' >Profit this year</p>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div className='svg-bg1'>
                                    <img src={dash5} width='100%' height='25px'></img>
                                </div>
                                <div className='ms-3'>
                                    <p className='profit'>$38,496.00</p>
                                    <p className='profit-txt' >Profit this year</p>
                                </div>
                            </div>
                        </div>
                        <button className='view-btn'>View Details</button>
                    </div>
                </div>
                <div className='dash-grid2'>
                    <div className='d-flex justify-content-between'>
                        <p  className='dash-title'>Product Sales</p>
                        <i className="bi bi-three-dots-vertical"></i>
                    </div>
                    <div id="chart" className='d-flex justify-content-center mt-5'>
                         <div id="chart">
                          <ReactApexChart options={donutOptions} series={donutSeries} type="donut" />
                        </div>
                    </div>
                    <div className='d-flex justify-content-center'>
                      <button className='best-btn'><span className='bi bi-lightning-charge'></span> Best Seller</button>
                    </div>
                    <div className='d-flex mt-5'>
                        <div>
                            <div className='d-flex'>
                                <p className='circle-bg1'></p><span className='circle-txt'>36% Modernize</span>
                            </div>
                            <div className='d-flex'>
                                <p className='circle-bg2'></p><span className='circle-txt'>22% Ample</span>
                            </div>
                        </div>
                        <div className='ms-4'>
                            <div className='d-flex'>
                                <p className='circle-bg3'></p><span className='circle-txt'>17% Spike</span>
                            </div>
                            <div className='d-flex'>
                                <p className='circle-bg4'></p><span className='circle-txt'>31% MaterialM</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}