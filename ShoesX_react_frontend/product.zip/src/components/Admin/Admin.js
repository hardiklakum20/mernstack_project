import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import '../Assets/scss/admin.css';
import flag from '../Assets/Images/world.png';
import { Link } from 'react-router-dom';

export function Admin(){

    const [isOpen, setIsOpen] = useState(false);

    return(
        <div>
            <div className="container d-flex p-0">
                {/* Sidebar Section */}
                <section id="toggle-section" className={`sidebar ${isOpen ? "open" : ""}`}>
                    <div className="Nav-content">
                        <div className="navbar-nav mb-2 mb-lg-0 pt-2">
                            <div className="d-flex justify-content-between">
                                <p className='brand'>ShoesX</p>
                                <button className="close-btn" onClick={() => setIsOpen(false)}   >
                                    <i className="bi bi-x-lg"></i>
                                </button>
                            </div>
                            <div>
                                <ul className="list-section">
                                    <li className="item">
                                      <Link to="/admin/dashboard" className="item-btn">Dashboard</Link>
                                    </li>
                                    <li className="item">
                                      <Link to="/admin/category" className="item-btn">Category</Link>
                                    </li>
                                    <li className="item">
                                       <Link to="/admin/banner" className="item-btn">Banner</Link>
                                    </li>
                                    <li className="item">
                                      <Link to="/admin/users" className="item-btn">Users</Link>
                                    </li>
                                    <li className="item">
                                        <Link to="/admin/product" className="item-btn">Product</Link>
                                    </li>
                                    <li className="item">
                                      <Link to="/admin/education" className="item-btn">Education</Link>
                                    </li>
                                    <li className="item">
                                      <Link to="/admin/features" className="item-btn">Features</Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Main Section */}
                <div className="main-section">
                    <nav className="navbar navbar-expand-lg">
                        <div className="d-flex justify-content-between align-items-center w-75">
                            {/* Toggle Button for Mobile */}
                            <div className="d-block d-lg-none">
                                <button className="navbar-toggler Navbar-toggler"  onClick={() => setIsOpen(!isOpen)}>
                                    <span className="navbar-toggler-icon"></span>
                                </button>
                            </div>
                            <div className='search-sec'>
                                <input type='text' className='search-bar'></input> 
                                <span className='search-icon'><i className="bi bi-search"></i></span>
                            </div>
                            <div className='d-flex'>
                                <i className="bi bi-moon icons1"></i>
                                <img  src={flag}  width="25px" height='25px' className="flag" alt="Flag"/>
                                <i className="bi bi-envelope icons1"></i>
                                <i className="bi bi-bell icons1"></i>
                            </div>
                        </div>
                    </nav>

                    <div className='content-wrapper'>
                        <Outlet/>
                    </div>
                </div>
            </div>

        </div>
    )
}