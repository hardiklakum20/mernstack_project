// import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Login } from './components/Admin/Login/login';
import { Admin } from './components/Admin/Admin';
import { Dashboard } from './components/Admin/Dashboard/dashboard';
import { User } from './components/Admin/User/user';
import { Category } from './components/Admin/Category/Category';
import Product from './components/Admin/Product/Product';
import AddProduct from './components/Admin/Product/AddProduct';
import ViewProduct from './components/Admin/Product/ViewProduct';
import EditProduct from './components/Admin/Product/EditProduct';

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/admin' element={<Admin />}>
            <Route path='/admin/dashboard' element={<Dashboard />}></Route>
            <Route path='/admin/users' element={<User />}></Route>
            <Route path='/admin/category' element={<Category />}></Route>
            <Route path='/admin/product' element={<Product />}></Route>
            <Route path='/admin/product/add-product' element={<AddProduct />}></Route>
            <Route path='/admin/product/view-product' element={<ViewProduct />}></Route>
            <Route path='/admin/product/edit-product' element={<EditProduct />}></Route>
          </Route>
          <Route path='/admin/login' element={<Login />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
