import React from 'react'

function EditRole() {
    return (
        <>
            <div className='add-role-head'>
                <h3>Edit Role</h3>
            </div>

            <div className='add-role-body body-bg'>
                <h5>Permissions</h5>
                <div className='permission-div'>
                    <h5>Dashboard:</h5>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="all" />
                        <label class="form-check-label" for="all">
                            All
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="view" />
                        <label class="form-check-label" for="view">
                            View
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="edit" />
                        <label class="form-check-label" for="edit">
                            Edit
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="add" />
                        <label class="form-check-label" for="add">
                            Add
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="delete" />
                        <label class="form-check-label" for="delete">
                            Delete
                        </label>
                    </div>
                </div>
                <div className='permission-div'>
                    <h5>Users :</h5>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="all" />
                        <label class="form-check-label" for="all">
                            All
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="view" />
                        <label class="form-check-label" for="view">
                            View
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="edit" />
                        <label class="form-check-label" for="edit">
                            Edit
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="add" />
                        <label class="form-check-label" for="add">
                            Add
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="delete" />
                        <label class="form-check-label" for="delete">
                            Delete
                        </label>
                    </div>
                </div>
                <div className='permission-div'>
                    <h5>Products :</h5>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="all" />
                        <label class="form-check-label" for="all">
                            All
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="view" />
                        <label class="form-check-label" for="view">
                            View
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="edit" />
                        <label class="form-check-label" for="edit">
                            Edit
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="add" />
                        <label class="form-check-label" for="add">
                            Add
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="delete" />
                        <label class="form-check-label" for="delete">
                            Delete
                        </label>
                    </div>
                </div>
                <div className='permission-div'>
                    <h5>Inquiry :</h5>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="all" />
                        <label class="form-check-label" for="all">
                            All
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="view" />
                        <label class="form-check-label" for="view">
                            View
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="edit" />
                        <label class="form-check-label" for="edit">
                            Edit
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="add" />
                        <label class="form-check-label" for="add">
                            Add
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="delete" />
                        <label class="form-check-label" for="delete">
                            Delete
                        </label>
                    </div>
                </div>
                <div className='permission-div'>
                    <h5>Orders :</h5>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="all" />
                        <label class="form-check-label" for="all">
                            All
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="view" />
                        <label class="form-check-label" for="view">
                            View
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="edit" />
                        <label class="form-check-label" for="edit">
                            Edit
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="add" />
                        <label class="form-check-label" for="add">
                            Add
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="delete" />
                        <label class="form-check-label" for="delete">
                            Delete
                        </label>
                    </div>
                </div>
                <div className='permission-div'>
                    <h5>Role :</h5>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="all" />
                        <label class="form-check-label" for="all">
                            All
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="view" />
                        <label class="form-check-label" for="view">
                            View
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="edit" />
                        <label class="form-check-label" for="edit">
                            Edit
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="add" />
                        <label class="form-check-label" for="add">
                            Add
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="delete" />
                        <label class="form-check-label" for="delete">
                            Delete
                        </label>
                    </div>
                </div>
                <div className='role-input'>
                    <div className="row">
                        <div className="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" class="form-control" id="name" />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div class="mb-3">
                                <label for="role-name" class="form-label">Role Name:</label>
                                <input type="text" class="form-control" id="role-name" />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" class="form-control" id="email" />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div class="mb-3">
                                <label for="Password" class="form-label">Password:</label>
                                <input type="password" class="form-control" id="Password" />
                            </div>
                        </div>
                        <div className="col-md-4">
                        <button className='btn default-btn'>Submit</button>
                        </div>
                    </div>
                    
                </div>
            </div>
        </>
    )
}

export default EditRole