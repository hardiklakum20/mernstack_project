import React, { useState } from 'react'
import { Link } from 'react-router-dom'

function Role() {

    const roleData = [
        {
            id: 1,
            name: "Manager",
            email: "manager@ecomus.com",
            action: <i class="fa-solid fa-pen-to-square"></i>,
        },
        {
            id: 2,
            name: "Admin",
            email: "admin@ecomus.com",
            action: <i class="fa-solid fa-pen-to-square"></i>,
        },
        {
            id: 3,
            name: "Editor",
            email: "editor@ecomus.com",
            action: <i class="fa-solid fa-pen-to-square"></i>,
        },
    ]

    const [role, setRole] = useState("");

    const filterRole = roleData.filter((item) => {
        return (
            item.name.toLowerCase().includes(role.toLowerCase())
        )
    })


    return (
        <>
            <div className='product-head'>
                <h3>Role</h3>
                <Link to={'/role/add-role'}><button className='btn' id='add-category-btn'>Add Role</button></Link>
            </div>
            <div className='product-body body-bg'>
            <div className='d-flex align-items-center justify-content-between flex-md-nowrap flex-wrap gap-3 gap-md-4'>
                    <div className='input-div'>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="gray" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="11" cy="11" r="8" />
                            <line x1="16" y1="16" x2="22" y2="22" />
                        </svg>
                        <input placeholder="Search Product" type="text" />
                    </div>
                    <div className='d-flex gap-md-3 gap-2 w-100'> 
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Active</option>
                            <option value="1">Inactive</option>                            
                        </select>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Category</option>
                            <option value="1">Brand</option>                            
                        </select>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Category</option>
                            <option value="1">Brand</option>                            
                        </select>
                    </div>
                </div>
                <div className='product-table table-responsive-xxl'>
                    <table class="table">
                        <thead className=''>
                            <tr>
                                <th>Role Name</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                filterRole.map((index) => {
                                    return (
                                        <tr key={index.id}>
                                            <td>{index.name}</td>
                                            <td>{index.email}</td>
                                            <td><Link to={"/role/edit-role"} className='text-black'>{index.action}</Link></td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>

            </div>
        </>
    )
}

export default Role