import React, { useEffect, useState } from 'react';
import ProfileImg from '../../Assets/Images/profile.jpg';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { useNavigate } from 'react-router-dom';

function Profile() {
    const [admin, setAdmin] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        const fetchAdmin = async () => {
            try {
                const token = localStorage.getItem("token");
                if (!token) {
                    navigate('/login');
                    return;
                }

                const decoded = jwtDecode(token);
                const currentTime = Date.now() / 1000;
                if (decoded.exp < currentTime) {
                    localStorage.removeItem("token");
                    navigate('/login');
                    return;
                }

                const adminId = decoded.id;
                const res = await axios.get(`http://localhost:1001/api/admin/${adminId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setAdmin(res.data.admin);
            } catch (err) {
                console.error("Failed to fetch admin:", err);
                localStorage.removeItem("token");
                navigate('/login');
            }
        };

        fetchAdmin();
    }, [navigate]);

    return (
        <>
            <div className='product-head'>
                <h3>Profile</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className='profile-body body-bg'>
                <div className='profile-content'>
                    <img src={ProfileImg} alt="profile" className='img-fluid' />
                    <div>
                        <h4>{admin.name || "sandip"}</h4>
                        <p>{admin.username || "sandip vegad"}</p>
                        <p>{admin.email || "sandip vegad"}</p>
                    </div>
                </div>
            </div>
            <div className='profile-info body-bg'>
                <h4>Personal Information</h4>
                <div className="row">
                    <div className="col-md-6">
                        <div className="mb-3">
                            <label htmlFor="useername" className="form-label">User Name</label>
                            <input type="text" className="form-control" id="useername" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="mb-3">
                            <label htmlFor="role" className="form-label">Role Name</label>
                            <input type="text" className="form-control" id="role" />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="mb-3">
                            <label htmlFor="email" className="form-label">Email</label>
                            <input type="email" className="form-control" id="email" />
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                        <button className='btn default-btn'>Submit</button>
                    </div>
            </div>
        </>
    );
}

export default Profile;
