import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function UserPage() {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [updateData, setUpdateData] = useState(false);
  const [selectItems, setSelectItems] = useState(null);
  const modalRef = useRef(null);


  // get data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          navigate("/admin/login");
          console.warn("No auth token found");
          return;
        }
        const response = await axios.get('http://localhost:1001/api/users/', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if (response.data?.success) {
          setData(response.data.data);
        } else {
          console.warn("No data received from API");
        }
      } catch (err) {
        console.error("Error fetching brand data:", err);
      }
    };
    fetchData();
  }, []);


  const handleUpdateClick = async (user) => {
    setSelectItems(user);
    setUpdateData(true);
  }

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();
    if (!selectItems) return;

    const original = data.find(item => item.id === selectItems.id);
    if (
      original &&
      original.status === selectItems.status
    ) {
      setErrorMessage("No changes detected.");
      setTimeout(() => setErrorMessage(""), 3000);
      return;
    }

    const token = localStorage.getItem("token");
    if (!token) {
      setErrorMessage("Unauthorized: No token found");
      return;
    }

    const decodedToken = JSON.parse(atob(token.split('.')[1]));
    const updateAt = decodedToken?.id;
    
    if (!updateAt) {
      setErrorMessage("User not found in token");
      return;
    }
    

    try {
      const token = localStorage.getItem("token");

      const response = await axios.put(
        `http://localhost:1001/api/users/update/${selectItems.id}`,
        {
          status: selectItems.status
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          }
        }
      );

      if (response.data.success) {
        setSuccessMessage(response.data.message || "Updated Successfully");
        setTimeout(() => setSuccessMessage(""), 3000);

        const updatedList = await axios.get('http://localhost:1001/api/users/', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setData(updatedList.data.data);
        setUpdateData(false);
        setSelectItems(null);
      } else {
        setErrorMessage(response.data.message || "No changes were made.");
        setTimeout(() => setErrorMessage(""), 3000);
      }
    } catch (err) {
      console.error("Error updating category:", err);
      setErrorMessage("Error while updating");
      setTimeout(() => setErrorMessage(""), 3000);
    }
  };

  return (
    <>
      <div className='product-head'>
        <h3>User</h3>
        {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
      </div>
      <div className='product-body body-bg'>
        <div className='d-flex align-items-center justify-content-between flex-md-nowrap flex-wrap gap-3 gap-md-4'>
          <div className='input-div'>
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="gray" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <line x1="16" y1="16" x2="22" y2="22" />
            </svg>
            <input placeholder="Search Product" type="text" />
          </div>
          <div className='d-flex gap-md-3 gap-2 w-100'>
            <select class="form-select" aria-label="Default select example">
              <option selected>Active</option>
              <option value="1">Inactive</option>
            </select>
            <select class="form-select" aria-label="Default select example">
              <option selected>Category</option>
              <option value="1">Brand</option>
            </select>
            <select class="form-select" aria-label="Default select example">
              <option selected>Category</option>
              <option value="1">Brand</option>
            </select>
          </div>
        </div>

        <div className="pt-4 text-center">
          {successMessage && <div className="text-success">{successMessage}</div>}
          {errorMessage && <div className="text-danger">{errorMessage}</div>}
        </div>

        <div className='product-table table-responsive-xxl'>
          <table class="table">
            <thead className=''>
              <tr>
                <th>User Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>password</th>
                <th>status</th>
                <th>lastLogin</th>
                <th>updateAt</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {data && data.length > 0 ? (
                data.map((user) => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.firstName}</td>
                    <td>{user.lastName}</td>
                    <td>{user.email}</td>
                    <td>{user.password}</td>
                    <td>{user.status}</td>
                    <td>{user.lastLogin ? new Date(user.lastLogin).toLocaleString() : "N/A"}</td>
                    <td>{user.updateAt ? new Date(user.updateAt).toLocaleString() : "N/A"}</td>

                    <button
                      className="btn btn-outline-success"
                      onClick={() => handleUpdateClick(user)}
                    >
                      Edit
                    </button>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="text-center">No users available</td>
                </tr>
              )}
            </tbody>
          </table>
          {
            updateData && selectItems && (
              <div className="modal show d-block" style={{ backgroundColor: 'rgba(0, 0, 0, 0.25)' }}>
                <div ref={modalRef} className="modal-dialog modal-dialog-centered">
                  <div className="modal-content p-4">
                    <form
                      onSubmit={handleUpdateSubmit}
                      className="bg-light p-4 rounded-md shadow-sm">
                      <label>Status</label>
                      <div>
                        <input
                          type="checkbox"
                          checked={selectItems.status}
                          onChange={(e) => setSelectItems({ ...selectItems, status: e.target.checked })}
                        />
                        <label> Active</label>
                      </div>
                      <button
                        type="submit"
                        className="btn btn-success w-100 mb-3">
                        Submit
                      </button>
                    </form>
                    <div className="d-flex justify-content-end p-4">
                      <button className="btn btn-danger"
                        onClick={() => setUpdateData(false)}>
                        Close
                      </button>
                    </div>
                    <div className="pt-4 text-center">
                      {successMessage && <div className="text-success">{successMessage}</div>}
                      {errorMessage && <div className="text-danger">{errorMessage}</div>}
                    </div>
                  </div>
                </div>
              </div>
            )
          }
        </div>
      </div>
    </>
  )
}

export default UserPage