import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../Assets/scss/Login.css';

export function Login() {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const [showPassword, setShowPassword] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const { data } = await axios.post(
                "http://localhost:1001/api/admin/login",
                { email, password },
                { headers: { "Content-Type": "application/json" } }
            );

            if (data.success === 1) {
                localStorage.setItem("token", data.token);
                navigate('/');
            } else {
                setMessage(data?.message);
            }
        } catch (err) {
            setMessage(err.response?.data?.message);
        }
    };

    return (
        <div className='d-flex'>
            <div className='login-side'>
                <div className='container'>
                    <p className='login-title'>Welcome to <br />ShoesX</p>
                    <p className='login-txt'>
                        Discover a world of style, comfort, and performance with ShoesX.
                        From casual sneakers to elegant formal wear and high-performance sports shoes,
                        we have the perfect pair for every occasion. Step up your shoe game with ShoesX!
                    </p>
                    <button className='learn-more-btn'>Learn More</button>
                </div>
            </div>

            <div className='login-main'>
                <div className='container d-flex justify-content-center align-items-center'>
                    <form onSubmit={handleSubmit}>
                        <div>
                            <label htmlFor="email" className="login-type mt-3">Email</label>
                            <input
                                type="email"
                                id="email"
                                value={email}
                                className='input-type'
                                onChange={(e) => setEmail(e.target.value)}
                            />

                            <label htmlFor="password" className="login-type mt-3">Password</label>
                            <input
                                type={showPassword ? "text" : "password"}
                                id="password"
                                value={password}
                                className='input-type'
                                onChange={(e) => setPassword(e.target.value)}
                            />

                            <div className="flex items-center mt-1">
                                <input
                                    type="checkbox"
                                    id="showPassword"
                                    checked={showPassword}
                                    onChange={() => setShowPassword(!showPassword)}
                                    className="mr-2"
                                />
                                <label htmlFor="showPassword" className="text-sm ms-2 mt-2">Show Password</label>
                            </div>

                            {message && <p className="mt-1 text-danger">{message}</p>}

                            <button
                                type="submit"
                                className='signin-btn mt-3'>
                                Login
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}