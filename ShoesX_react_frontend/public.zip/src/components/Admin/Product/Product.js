import React, { useEffect, useState } from "react";
import { useNavigate, Link, Navigate } from "react-router-dom";
import axios from "axios";
import '../../Assets/scss/product.css';
import ProductOne from '../../Assets/Images/product-table-1.jpg';

function Product() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get("http://localhost:1001/api/product");
                setProducts(response.data.products);
                setLoading(false);
            } catch (err) {
                console.error("Error fetching products:", err);
                setError("Failed to load products");
                setLoading(false);
            }
        };

        fetchProducts();
    }, []);

    return (
        <>
            <div className='product-head'>
                <h3>Product List</h3>                
                <button className='btn' id='add-category-btn' onClick={() => navigate('/product/add-product')}>Add Product</button>                
            </div>

            <div className='product-body body-bg'>
                <div className='d-flex align-items-center justify-content-between flex-md-nowrap flex-wrap gap-3 gap-md-4'>
                    <div className='input-div'>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="gray" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="11" cy="11" r="8" />
                            <line x1="16" y1="16" x2="22" y2="22" />
                        </svg>
                        <input placeholder="Search Product" type="text" />
                    </div>
                    <div className='d-flex gap-md-3 gap-2 w-100'>
                        <select className="form-select">
                            <option selected>Active</option>
                            <option value="1">Inactive</option>
                        </select>
                        <select className="form-select">
                            <option selected>Category</option>
                            <option value="1">Brand</option>
                        </select>
                        <select className="form-select">
                            <option selected>Category</option>
                            <option value="1">Brand</option>
                        </select>
                    </div>
                </div>

                {loading ? (
                    <p>Loading...</p>
                ) : error ? (
                    <p>{error}</p>
                ) : (
                    <div className='product-table table-responsive-xxl'>
                        <table className="table align-middle">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Products</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products && products?.map((product, index) => (
                                    <tr key={product.id || index}>
                                        <td>{product.id}</td>
                                        <td className='product-name'>
                                            <img src={product.image || ProductOne} alt="product" />
                                            <h5>{product.name}</h5>
                                        </td>
                                        <td>{new Date(product.createdAt).toDateString()}</td>
                                        <td>
                                            <span className={product.status === "InStock" ? 'in-stock' : 'out-stock'}>
                                                {product.status}
                                            </span>
                                        </td>
                                        <td><p>${product.price}</p></td>
                                        <td>
                                            <div className="dropdown">
                                                <button className="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <svg stroke="currentColor" fill="none" strokeWidth="2" viewBox="0 0 24 24" height="22" width="22" xmlns="http://www.w3.org/2000/svg">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 5v.01M12 12v.01M12 19v.01" />
                                                    </svg>
                                                </button>
                                                <ul className="dropdown-menu">
                                                    <li onClick={() => navigate('/product/edit-product')}><a className="dropdown-item">Edit</a></li>
                                                    <li>
                                                        <a className="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                            Delete
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Delete Modal */}
            <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-body">
                            <h5>Are you sure you want to delete selected products?</h5>
                        </div>
                        <div className="modal-footer border-top-0">
                            <button type="button" className="btn delete-btn">Delete</button>
                            <button className='btn btn-closes' data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Product;
