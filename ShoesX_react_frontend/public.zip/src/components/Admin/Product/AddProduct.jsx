import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import '../../Assets/scss/product.css';

function AddProduct() {
    const navigate = useNavigate();
    const [brands, setBrands] = useState([]);
    const [brandId, setBrandId] = useState("");
    const [statusFlag, setStatusFlag] = useState("1");

    // Product form state
    const [formData, setFormData] = useState({
        name: "",
        description: "",
        price: "",
        discount: "",
        sku: "",
        stock: "",
        material: "",
    });

    const [imageFile, setImageFile] = useState(null);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    useEffect(() => {
        const fetchData = async () => {
            const token = localStorage.getItem("token");
            if (!token) {
                navigate("/login");
                console.warn("No auth token found");
                return;
            }

            try {
                const brandRes = await axios.get("http://localhost:1001/api/brand", {
                    headers: { Authorization: `Bearer ${token}` }
                });

                if (brandRes.data?.success === 1) {
                    setBrands(brandRes.data.results);
                }
            } catch (err) {
                console.error("Error fetching data:", err);
            }
        };

        fetchData();
    }, [navigate]);

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData({ ...formData, [id]: value });
    };

    const handleImageChange = (e) => {
        setImageFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSuccess("");

        const token = localStorage.getItem("token");
        if (!token) {
            setError("Unauthorized");
            return;
        }

        const decodedToken = JSON.parse(atob(token.split('.')[1]));
        const createUser = decodedToken?.id;

        if (!createUser) {
            setError("Invalid token: user not found.");
            return;
        }

        try {
            const data = new FormData();
            data.append("name", formData.name);
            data.append("description", formData.description);
            data.append("price", formData.price);
            data.append("discount", formData.discount);
            data.append("sku", formData.sku);
            data.append("stock", formData.stock);
            data.append("material", formData.material);
            data.append("brandId", brandId);
            data.append("statusFlag", statusFlag);
            data.append("createUser", createUser);
            data.append("image", imageFile);


            const response = await axios.post("http://localhost:1001/api/product/create", data, {
                headers: {
                    "Content-Type": "multipart/form-data",
                    Authorization: `Bearer ${token}`,
                },
            });

            console.log(response);


            if (response.data.success === 1) {
                setSuccess("Product created successfully.");
                navigate("/product");
            } else {
                setError(response.data.message || "Failed to create product.");
            }

        } catch (err) {
            console.error(err);
            setError(err.response?.data?.message || "Something went wrong.");
        }
    };

    return (
        <>
            <div className='product-head'><h3>Add Product</h3></div>
            <form onSubmit={handleSubmit}>
                <div className='add-product-body body-bg'>
                    <h3>General</h3>
                    <div className="row">
                        <div className="col-md-12 mb-3">
                            <label>Product Name <span>*</span></label>
                            <input type="text" className="form-control" id="name" value={formData.name} onChange={handleInputChange} required />
                        </div>
                        <div className="col-md-12 mb-3">
                            <label>Description</label>
                            <textarea className="form-control" id="description" value={formData.description} onChange={handleInputChange} rows="4" />
                        </div>
                    </div>
                </div>

                <div className='add-product-body body-bg'>
                    <h3>Media</h3>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="drop-zone">
                                <span className="drop-zone__prompt">Click to upload or drag and drop</span>
                                <input type="file" name="image" className="drop-zone__input" onChange={handleImageChange} multiple />
                            </div>
                        </div>
                    </div>
                </div>

                <div className='add-product-body body-bg'>
                    <h3>Pricing</h3>
                    <div className="row">
                        <div className="col-md-12 mb-3">
                            <label>Price <span>*</span></label>
                            <input type="number" className="form-control" id="price" value={formData.price} onChange={handleInputChange} required />
                        </div>
                        <div className="col-md-12 mb-3">
                            <label>Discount</label>
                            <input type="number" className="form-control" id="discount" value={formData.discount} onChange={handleInputChange} />
                        </div>
                        <div className="col-md-12 mb-3">
                            <label>SKU <span>*</span></label>
                            <input type="text" className="form-control" id="sku" value={formData.sku} onChange={handleInputChange} required />
                        </div>
                    </div>
                </div>

                <div className='add-product-body body-bg'>
                    <h3>Product Details</h3>
                    <div className="col-md-12 mb-3">
                        <label>Status <span>*</span></label>
                        <select className="form-select" value={statusFlag} onChange={(e) => setStatusFlag(e.target.value)} required>
                            <option value="">-- Select Status --</option>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>

                    <div className="col-md-12 mb-3">
                        <label>Brand <span>*</span></label>
                        <select className="form-select" value={brandId} onChange={(e) => setBrandId(e.target.value)} required>
                            <option value="">-- Select Brand --</option>
                            {brands?.map((brand) => (
                                <option key={brand.id} value={brand.id}>{brand.name}</option>
                            ))}
                        </select>
                    </div>

                    <div className="col-md-12 mb-3">
                        <label>Material <span>*</span></label>
                        <input type="text" className="form-control" id="material" value={formData.material} onChange={handleInputChange} required />
                    </div>
                </div>

                <div className='d-flex gap-3 mt-4'>
                    <button type="submit" className='btn default-btn'>Save Changes</button>
                    <button type="button" className='btn btn-closes' onClick={() => navigate(-1)}>Cancel</button>
                </div>

                {error && <div className="text-danger mt-2">{error}</div>}
                {success && <div className="text-success mt-2">{success}</div>}
            </form>
        </>
    );
}

export default AddProduct;