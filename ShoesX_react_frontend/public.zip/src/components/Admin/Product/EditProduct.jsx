import React from 'react'
import '../../Assets/scss/product.css'

function EditProduct() {
    return (
        <>
            <div className='product-head'>
                <h3>Edit Product</h3>
            </div>

            <div className='add-product-body body-bg'>
                <h3>General</h3>
                <div className="row">
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name <span>*</span></label>
                            <input type="text" class="form-control" id="name" placeholder="Product Name" />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" placeholder="Description" rows="4" id="floatingTextarea"></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div className='add-product-body body-bg'>
                <h3>Media</h3>
                <div className="row">
                    <div className="col-md-12">
                        <div class="drop-zone">
                            <span class="drop-zone__prompt">Click to upload or drag and drop</span>
                            <input type="file" name="myFile" class="drop-zone__input" />
                        </div>
                    </div>
                </div>
            </div>

            <div className='add-product-body body-bg'>
                <h3>Variation</h3>
                <div className="row">
                    <div className="col-md-4">
                        <div class="mb-3 mb-md-0">
                            <label for="name" class="form-label">Product Name <span>*</span></label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Size</option>
                                <option value="1">Color</option>
                                <option value="2">Material</option>
                                <option value="3">SKU</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div class="mb-3 mb-md-0">
                            <label for="name" class="form-label">Variation</label>
                            <input type="text" class="form-control" id="name" placeholder="Variation" />
                        </div>
                    </div>
                    <div className="col-md-4 d-flex align-items-end">
                        <button className='btn btn-closes'>
                            <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true" height="20" width="20" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>
                        </button>
                    </div>
                    <div className="col-md-6">
                        <button className='btn btn-add'>
                            <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true" height="18" width="18" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                            Add another variation
                        </button>
                    </div>
                </div>
            </div>

            <div className='add-product-body body-bg'>
                <h3>Pricing</h3>
                <div className="row">
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="name" class="form-label">Price <span>*</span></label>
                            <input type="text" class="form-control" id="name" placeholder="Product Price" />
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="name" class="form-label">Discount</label>
                            <input type="text" class="form-control" id="name" placeholder="Discount" />
                        </div>
                    </div>
                </div>
            </div>

            <div className='add-product-body body-bg'>
                <h3>Product Details</h3>
                <div className="row">
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="name" class="form-label">Category <span>*</span></label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Leather</option>
                                <option value="1">Party ware</option>
                                <option value="2">Material</option>
                                <option value="3">SKU</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="name" class="form-label">Brand <span>*</span></label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Bata</option>
                                <option value="1">Addidas</option>
                                <option value="2">Material</option>
                                <option value="3">SKU</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <div class="mb-3">
                            <label for="name" class="form-label">Stock <span>*</span></label>
                            <input type="text" class="form-control" id="name" placeholder="Stock" />
                        </div>
                    </div>
                </div>
            </div>

            <div className='d-flex gap-3 mt-4'>
                <button className='btn default-btn'>Save Changes</button>
                <button className='btn btn-closes'>
                    Cancel
                </button>
            </div>

        </>
    )
}

export default EditProduct