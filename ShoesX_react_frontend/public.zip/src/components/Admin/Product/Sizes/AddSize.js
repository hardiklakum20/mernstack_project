import { useNavigate } from "react-router-dom";
import React, { useState } from "react";
import axios from "axios";

export function AddSize() {

    const navigate = useNavigate();
    const [Name, setName] = useState("");
    const [statusFlag, setStatusFlag] = useState(true); // Default to true (1)
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSuccessMessage("");
        setErrorMessage("");

        if (!Name) {
            setErrorMessage("Please enter all fields");
            return;
        }

        const token = localStorage.getItem("token");
        if (!token) {
            setErrorMessage("Unauthorized: No token found");
            return;
        }

        const decodedToken = JSON.parse(atob(token.split('.')[1]));
        const createUser = decodedToken?.id;

        if (!createUser) {
            setErrorMessage("User not found in token");
            return;
        }

        try {
            const response = await axios.post(
                "http://localhost:1001/api/size/create",
                {
                    name: Name,
                    statusFlag: statusFlag ? 1 : 0,
                    createUser,
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                }
            );

            if (response.data.success) {
                setName("");
                setStatusFlag(true);
                setSuccessMessage("Size created successfully");
                setTimeout(() => setSuccessMessage(""), 3000);
                navigate('/product/size');
            } else {
                setErrorMessage(response.data.message || "Error in size creation");
                setTimeout(() => setErrorMessage(""), 3000);
            }
        } catch (err) {
            console.error(err);
            if (err.response?.data?.message) {
                setErrorMessage(err.response.data.message);
            } else {
                setErrorMessage("Error while uploading");
            }
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleNameChange = (e) => {
        setName(e.target.value);
        if (successMessage || errorMessage) {
            setSuccessMessage("");
            setErrorMessage("");
        }
    };

    return (
        <>
            <div className='product-head'>
                <h3>Add Size</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className='categroy-description'>
                <form onSubmit={handleSubmit}>
                    <div>
                        <div>
                            <label className='category-brand'>Size</label>
                            <div>
                                <input
                                    type='text'
                                    className='add-category'
                                    placeholder='Enter Size'
                                    value={Name}
                                    onChange={handleNameChange}
                                    name='Size'
                                    required
                                />
                            </div>
                        </div>

                        <div>
                            <label className="category-brand">Select Status Flag</label>
                            <select
                                className="add-category"
                                value={statusFlag ? "1" : "0"}
                                onChange={(e) => setStatusFlag(e.target.value === "1")}
                                required
                            >
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <div className='d-flex justify-content-end'>
                            <button type='submit' className='add-btn'>
                                Add
                            </button>
                        </div>

                        {successMessage && <div className="text-success">{successMessage}</div>}
                        {errorMessage && <div className="text-danger">{errorMessage}</div>}
                    </div>
                </form>
            </div>
        </>
    );
}