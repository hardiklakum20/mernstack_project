import { useNavigate } from 'react-router-dom';
import '../../../Assets/scss/category.css';
import React, { useState, useEffect, useRef } from "react";
import axios from "axios";

export function Size() {
    const navigate = useNavigate();
    const modalRef = useRef(null);

    const [data, setData] = useState([]);
    const [updateData, setUpdateData] = useState(false);
    const [selectItems, setSelectItems] = useState(null);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    const token = localStorage.getItem("token");


    useEffect(() => {
        if (!token) return;

        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:1001/api/size/', {
                    headers: { Authorization: `Bearer ${token}` }
                });

                if (response.data?.success) {
                    setData(response.data.data);
                } else {
                    console.warn("No data received from API");
                }
            } catch (err) {
                console.error("Error fetching size data:", err);
            }
        };

        fetchData();
    }, [token]);

    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:1001/api/size/delete/${id}`, {
                headers: { Authorization: `Bearer ${token}` },
            });

            setData(prev => prev.filter(item => item.id !== id));
        } catch (err) {
            console.error("Error deleting size:", err);
        }
    };



    return (
        <>
            <div className='product-head'>
                <p id='category'>Size</p>
                <button id='add-category-btn' onClick={() => navigate('/product/size/add')}>Add Size</button>
            </div>

            <div className='categroy-description body-bg'>
                <div>
                    <input type='text' placeholder='Search Size' className='search-bar' />
                </div>

                <div className="pt-4 text-center">
                    {successMessage && <div className="text-success">{successMessage}</div>}
                    {errorMessage && <div className="text-danger">{errorMessage}</div>}
                </div>
                <div className="product-table table-responsive-xxl">

                <table className="table align-middle">
                    <thead>
                        <tr className="text-center">
                            <th>Id</th>
                            <th>Size</th>
                            <th>statusFlag</th>
                            <th>createAt</th>
                            <th>updateAt</th>
                            <th>createUser</th>
                            <th>updateUser</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {Array.isArray(data) && data.length > 0 ? (
                            data.map((item) => (
                                <tr key={item.id} className="text-center">
                                    <td>{item.id}</td>
                                    <td>{item.name}</td>
                                    <td>{item.statusFlag}</td>
                                    <td>{new Date(item.createAt).toLocaleString()}</td>
                                    <td>{new Date(item.updateAt).toLocaleString()}</td>
                                    <td>{item.createUser}</td>
                                    <td>{item.updateUser}</td>
                                    <td>
                                        <button
                                            className="btn btn-outline-success"
                                            onClick={() => navigate('edit', { state: item })}
                                        >
                                            Edit
                                        </button>
                                        <button
                                            className="btn btn-outline-danger ms-2"
                                            onClick={() => handleDelete(item.id)}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr className='text-center'>
                                <td colSpan="10">No Size available</td>
                            </tr>
                        )}
                    </tbody>
                </table>
                </div>
            </div>
        </>
    );
}
