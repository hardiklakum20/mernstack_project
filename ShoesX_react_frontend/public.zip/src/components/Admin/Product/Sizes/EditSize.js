import { useNavigate, useLocation } from "react-router-dom";
import React, { useState } from "react";
import axios from "axios";

export function EditSize() {
    const navigate = useNavigate();
    const { state } = useLocation();
    ;

    const [Name, setName] = useState(state?.name);
    const [statusFlag, setStatusFlag] = useState(state?.statusFlag);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSuccessMessage("");
        setErrorMessage("");

        const token = localStorage.getItem("token");
        if (!token) {
            setErrorMessage("Unauthorized: No token found");
            return;
        }

        const decodedToken = JSON.parse(atob(token.split('.')[1]));
        const updateUser = decodedToken?.id;

        if (!updateUser) {
            setErrorMessage("User not found in token");
            return;
        }

        try {
            const { data } = await axios.put(
                `http://localhost:1001/api/size/update/${state?.id}`,
                {
                    name: Name,
                    statusFlag: statusFlag ? 1 : 0,
                    updateUser,
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                }
            );

            if (data.success === 1) {
                setSuccessMessage("Size updated successfully");
                setSuccessMessage("");
                navigate('/product/size');
            } else {
                setErrorMessage(data.message || "Error updating size");
                setTimeout(() => setErrorMessage(""), 3000);
            }
        } catch (err) {
            console.error(err);
            setErrorMessage(err.response?.data?.message || "Error while updating");
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleNameChange = (e) => {
        setName(e.target.value);
        if (successMessage || errorMessage) {
            setSuccessMessage("");
            setErrorMessage("");
        }
    };

    return (
        <>
            <div className='product-head'>
                <h3>Edit Size</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className='categroy-description'>
                <form onSubmit={handleSubmit}>
                    <div>
                        <div>
                            <label className='category-brand'>Size</label>
                            <div>
                                <input
                                    type='text'
                                    className='add-category'
                                    placeholder='Enter Size'
                                    value={Name}
                                    onChange={handleNameChange}
                                    name='Size'
                                    required
                                />
                            </div>
                        </div>

                        <div>
                            <label className="category-brand">Select Status Flag</label>
                            <select
                                className="add-category"
                                value={statusFlag ? "1" : "0"}
                                onChange={(e) => setStatusFlag(e.target.value === "1")}
                                required
                            >
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <div className='d-flex justify-content-end'>
                            <button type='submit' className='add-btn'>
                                Update
                            </button>
                        </div>

                        {successMessage && <div className="text-success">{successMessage}</div>}
                        {errorMessage && <div className="text-danger">{errorMessage}</div>}
                    </div>
                </form>
            </div>
        </>
    );
}