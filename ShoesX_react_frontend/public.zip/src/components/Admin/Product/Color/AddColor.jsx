import { useNavigate } from 'react-router-dom';
import '../../../Assets/scss/category.css';
import React, { useState } from "react";
import axios from "axios";

export function AddColor() {
    const navigate = useNavigate();
    const [Name, setName] = useState("");
    const [statusFlag, setStatusFlag] = useState(true);
    const [errorMessage, setErrorMessage] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        const token = localStorage.getItem("token");
        if (!token) {
            setErrorMessage("Unauthorized: No token found");
            return;
        }

        const decodedToken = JSON.parse(atob(token.split('.')[1]));
        const createUser = decodedToken?.id;

        try {
            const { data } = await axios.post(
                "http://localhost:1001/api/color/create",
                {
                    name: Name,
                    createUser,
                    statusFlag: statusFlag ? 1 : 0
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                }
            );

            if (data.success === 1) {
                setName("");
                navigate('/color');
            } else {
                setErrorMessage(data.message || "Error in color creation");
                setTimeout(() => setErrorMessage(""), 3000);
            }
        } catch (err) {
            console.error(err);
            if (err.response?.data?.message) {
                setErrorMessage(err.response.data.message);
            } else {
                setErrorMessage("Error while uploading");
            }
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleNameChange = (e) => {
        setName(e.target.value);
        setErrorMessage("");
    }

    return (
        <>
            <div className='product-head'>
                <h3>Add Color</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className='categroy-description'>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label className='category-brand'>Color</label>
                        <input
                            type='text'
                            className='add-category'
                            placeholder='Enter Color'
                            value={Name}
                            onChange={handleNameChange}
                            name='Color'
                            required
                        />
                    </div>

                    <div>
                        <label className="category-brand">Select Status Flag</label>
                        <select
                            className="add-category"
                            value={statusFlag ? "1" : "0"}
                            onChange={(e) => setStatusFlag(e.target.value === "1")}
                            required
                        >
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>

                    <div className='d-flex justify-content-end'>
                        <button type='submit' className='add-btn'>Add</button>
                    </div>

                    {errorMessage && <div className="text-danger mt-3">{errorMessage}</div>}
                </form>
            </div>
        </>
    );
}