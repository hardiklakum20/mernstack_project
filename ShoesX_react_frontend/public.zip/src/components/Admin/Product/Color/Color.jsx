import { useNavigate } from 'react-router-dom';
import '../../../Assets/scss/category.css';
import React, { useState, useEffect, } from "react";
import axios from "axios";

export function Color() {

    const navigate = useNavigate();
    const [data, setData] = useState([]);
    const [message, setMessage] = useState("");

    useEffect(() => {
        const fetchData = async () => {
            const token = localStorage.getItem("token");
            if (!token) {
                console.warn("No auth token found");
                return;
            }
            try {
                const { data } = await axios.get('http://localhost:1001/api/color/', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                if (data?.success === 1) {
                    setData(data.data);
                } else {
                    console.warn("No data received from API");
                }
            } catch (err) {
                console.error("Error fetching brand data:", err);
            }
        };
        fetchData();
    }, []);


    const handleDelete = async (id) => {
        try {
            const token = localStorage.getItem("token");
            await axios.delete(`http://localhost:1001/api/color/delete/${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setData(data.filter((item) => item.id !== id));
        } catch (err) {
            console.log("Error Deleting Data", err);
        }
    };


    return (
        <>
            <div className='product-head'>
                <p id='category'>Color</p>
                <button id='add-category-btn' onClick={() => navigate('/addColor')}>Add Color</button>
            </div>

            <div className='categroy-description body-bg'>
                <div>
                    <input type='text' placeholder='Search Color' className='search-bar' />
                </div>

                <div className="pt-4 text-center">
                    {message && <div className="text-success">{message}</div>}
                </div>
                <div className="product-table table-responsive-xxl">

                <table class="table align-middle">
                    <thead>
                        <tr className="text-center">
                            <th>Id</th>
                            <th>Color</th>
                            <th>statusFlag</th>
                            <th>createAt</th>
                            <th>updateAt</th>
                            <th>createUser</th>
                            <th>updateUser</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {Array.isArray(data) && data.length > 0 ? (
                            data.map((item) => (
                                <tr key={item.id} className="text-center">
                                    <td>{item.id}</td>
                                    <td>{item.name}</td>
                                    <td>{item.statusFlag}</td>
                                    <td>{new Date(item.createAt).toLocaleString()}</td>
                                    <td>{new Date(item.updateAt).toLocaleString()}</td>
                                    <td>{item.createUser}</td>
                                    <td>{item.updateUser}</td>
                                    <td>
                                        <button
                                            className="btn btn-outline-success"
                                            onClick={() => navigate('/editcolor', { state: item })}
                                        >
                                            Edit
                                        </button>
                                        <button
                                            className="btn btn-outline-danger ms-2"
                                            onClick={() => handleDelete(item.id)}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr className='text-center'>
                                <td colSpan="10">No Color available</td>
                            </tr>
                        )}
                    </tbody>
                </table>
                </div>
            </div>
        </>
    )
}

