import { useNavigate } from "react-router-dom";
import React, { useState, useEffect } from "react";
import axios from "axios";

export function Brand() {
    const navigate = useNavigate();

    const [data, setData] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedImage, setSelectedImage] = useState(null);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");
    const [loading, setLoading] = useState(true); // Loading state

    const token = localStorage.getItem("token");

    const fetchAllBrands = async () => {
        if (!token) return;
        setLoading(true); // Start loading
        try {
            const res = await axios.get('http://localhost:1001/api/brand/', {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (res.data?.success) {
                setData(res.data.results);
                setFilteredData(res.data.results); // Initialize filtered data with all brands
            } else {
                setErrorMessage("Failed to fetch brands");
            }
        } catch (err) {
            console.error("Fetch error:", err);
            setErrorMessage("An error occurred while fetching data");
        } finally {
            setLoading(false); // End loading
        }
    };

    const handleDelete = async (id) => {
        setLoading(true);
        try {
            await axios.delete(`http://localhost:1001/api/brand/delete/${id}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setSuccessMessage("Brand deleted successfully");
            fetchAllBrands();
        } catch (err) {
            console.error("Delete error:", err);
            setErrorMessage("An error occurred while deleting the brand");
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (event) => {
        const term = event.target.value;
        setSearchTerm(term);
        if (term === "") {
            setFilteredData(data);
        } else {
            setFilteredData(data.filter(item => item.name.toLowerCase().includes(term.toLowerCase())));
        }
    };

    useEffect(() => {
        fetchAllBrands();
    }, []);

    return (
        <>
            <div className='Category-head d-flex justify-content-between'>
                <p id='category'>Brand</p>
                <button id='add-category-btn' onClick={() => navigate('/product/brand/add')}>Add Brand</button>
            </div>

            <div className='categroy-description body-bg'>
                <div>
                    <input
                        type="text"
                        placeholder="Search Brand"
                        className="search-bar"
                        value={searchTerm}
                        onChange={handleSearch}
                    />
                </div>

                <div className="">
                    {successMessage && <div className="text-success">{successMessage}</div>}
                    {errorMessage && <div className="text-danger">{errorMessage}</div>}
                </div>

                {loading ? (
                    <div>Loading...</div>
                ) : (
                    <div className="product-table table-responsive">
                        <table className="table align-middle">
                            <thead>
                                <tr className="text-center">
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Image</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                    <th>Created By</th>
                                    <th>Updated By</th>
                                    <th>Category ID</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredData.length > 0 ? (
                                    filteredData.map((item) => (
                                        <tr key={item.id} className="text-center">
                                            <td>{item.id}</td>
                                            <td>{item.name}</td>
                                            <td>{item.statusFlag}</td>
                                            <td>
                                                <div className="d-flex justify-content-center align-items-center">
                                                    <img
                                                        src={`http://localhost:1001${item.image}`}
                                                        alt={item.name}
                                                        className="img-thumbnail"
                                                        style={{ maxWidth: "50px", maxHeight: "50px", objectFit: "cover" }}
                                                        onClick={() => setSelectedImage(`http://localhost:1001${item.image}`)}
                                                    />
                                                </div>
                                            </td>
                                            <td>{new Date(item.createAt).toLocaleString()}</td>
                                            <td>{new Date(item.updateAt).toLocaleString()}</td>
                                            <td>{item.createUser}</td>
                                            <td>{item.updateUser}</td>
                                            <td>{item.categoryId}</td>
                                            <td>
                                                <button className="btn btn-outline-success" onClick={() => navigate('edit', { state: item })}>Edit</button>
                                                <button className="btn btn-outline-danger ms-2" onClick={() => handleDelete(item.id)}>Delete</button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr className="text-center">
                                        <td colSpan="10">No brands available</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                )}

                {selectedImage && (
                    <div className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-75 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
                        <div className="position-relative">
                            <img src={selectedImage} alt="Large Preview" className="img-fluid rounded shadow-lg" style={{ maxWidth: '90vw', maxHeight: '80vh' }} />
                            <button className="btn-close position-absolute top-0 end-0 m-2" onClick={() => setSelectedImage(null)} />
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}