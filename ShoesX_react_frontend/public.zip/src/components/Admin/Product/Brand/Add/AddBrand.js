import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../../../../Assets/scss/category.css";

export function AddBrand() {
    const navigate = useNavigate();

    const [categories, setCategories] = useState([]);
    const [categoryId, setCategoryId] = useState([]);
    const [name, setName] = useState("");
    const [imgFile, setImgFile] = useState(null);
    const [showImg, setShowImg] = useState(null);
    const [showPreview, setShowPreview] = useState(true);
    const [statusFlag, setStatusFlag] = useState(true);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (!token) return navigate("/login");

        axios.get("http://localhost:1001/api/category/", {
            headers: { Authorization: `Bearer ${token}` },
        }).then(res => {
            if (res.data?.success) setCategories(res.data.data);
        }).catch(() => {
            setErrorMessage("Failed to fetch categories.");
            setTimeout(() => setErrorMessage(""), 3000);
        });
    }, [navigate]);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImgFile(file);
            setShowImg(URL.createObjectURL(file));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSuccessMessage("");
        setErrorMessage("");

        console.log("Submitting brand form...");

        if (!name || !imgFile || categoryId.length === 0) {
            console.error("Validation failed", { name, imgFile, categoryId });
            setErrorMessage("Please fill in all required fields.");
            setTimeout(() => setErrorMessage(""), 3000);
            return;
        }

        const token = localStorage.getItem("token");
        if (!token) {
            console.error("No token found");
            return setErrorMessage("Unauthorized: No token found");
        }

        let createUser;
        try {
            createUser = JSON.parse(atob(token.split('.')[1]))?.id;
        } catch (error) {
            console.error("Token decoding failed:", error);
            setErrorMessage("Invalid token format");
            return;
        }

        const formData = new FormData();
        formData.append("name", name);
        formData.append("image", imgFile);
        formData.append("createUser", createUser);
        formData.append("statusFlag", statusFlag ? 1 : 0);
        categoryId.forEach(id => formData.append("categoryId", id));

        console.log("Form Data Preview:");
        console.log("name:", name);
        console.log("image:", imgFile);
        console.log("createUser:", createUser);
        console.log("statusFlag:", statusFlag);
        console.log("categoryId:", categoryId);

        try {
            const res = await axios.post("http://localhost:1001/api/brand/create", formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                    Authorization: `Bearer ${token}`,
                },
            });

            console.log("Response from server:", res.data);

            if (res.data.success === 1) {
                setSuccessMessage(res.data.message);
                navigate("/product/brand");
            } else {
                console.error("Server error:", res.data.message);
                setErrorMessage(res.data.message || "Error in brand creation");
            }
        } catch (err) {
            const msg = err?.response?.data?.message || "Error while uploading";
            console.error("Catch block error:", err.response?.data || err.message);
            setErrorMessage(msg);
        }

        setTimeout(() => {
            setErrorMessage("");
            setSuccessMessage("");
        }, 3000);
    };


    return (
        <>
            <div className='product-head'>
                <h3>Add Brand</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className="categroy-description">
                <form onSubmit={handleSubmit}>
                    <div>
                        <label className="category-brand">Brand Name</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="add-category"
                            placeholder="Enter the Brand Name"
                            required
                        />
                    </div>

                    <div>
                        <label className="category-brand">Select Categories</label>
                        <select
                            className="add-category"
                            value={categoryId}
                            onChange={(e) =>
                                setCategoryId(Array.from(e.target.selectedOptions, opt => opt.value))
                            }
                            multiple
                            required
                            size={5}
                        >
                            {categories.map((cat) => (
                                <option key={cat.id} value={cat.id}>
                                    {cat.name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="category-brand">Status</label>
                        <select
                            className="add-category"
                            value={statusFlag ? "1" : "0"}
                            onChange={(e) => setStatusFlag(e.target.value === "1")}
                        >
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>

                    <div>
                        <label className="category-brand">Brand Image</label>
                        <input
                            type="file"
                            onChange={handleImageChange}
                            className="add-category"
                            required
                        />
                        <div className="mt-2">
                            <input
                                type="checkbox"
                                checked={showPreview}
                                onChange={() => setShowPreview(!showPreview)}
                            />
                            <label className="ms-2">Show Image Preview</label>
                            {showPreview && showImg && (
                                <img
                                    src={showImg}
                                    alt="Preview"
                                    className="img-fluid mt-2"
                                    style={{ width: '8rem', height: '8rem', objectFit: 'contain' }}
                                />
                            )}
                        </div>
                    </div>

                    <div className="d-flex justify-content-end mt-3">
                        <button type="submit" className="add-btn">Add</button>
                    </div>

                    {successMessage && <div className="text-success mt-3">{successMessage}</div>}
                    {errorMessage && <div className="text-danger mt-3">{errorMessage}</div>}
                </form>
            </div>
        </>
    );
}