import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import "../../../../Assets/scss/category.css";

export function EditBrand() {
    const navigate = useNavigate();
    const { state } = useLocation();

    const [categories, setCategories] = useState([]);
    const [categoryId, setCategoryId] = useState([]);
    const [name, setName] = useState(state?.name);
    const [imgFile, setImgFile] = useState(null);
    const [showImg, setShowImg] = useState(null);
    const [statusFlag, setStatusFlag] = useState(state?.statusFlag)
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (!token) return navigate("/login");

        axios.get("http://localhost:1001/api/category/", {
            headers: { Authorization: `Bearer ${token}` },
        }).then(res => {
            if (res.data?.success) setCategories(res.data.data);
        }).catch(() => {
            setErrorMessage("Failed to fetch categories.");
            setTimeout(() => setErrorMessage(""), 3000);
        });

    }, [navigate, state?.id]);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImgFile(file);
            setShowImg(URL.createObjectURL(file));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSuccessMessage("");
        setErrorMessage("");

        const token = localStorage.getItem("token");
        if (!token) return setErrorMessage("Unauthorized: No token found");

        let createUser;
        try {
            createUser = JSON.parse(atob(token.split('.')[1]))?.id;
        } catch (error) {
            setErrorMessage("Invalid token format");
            return;
        }

        const formData = new FormData();
        if (name) formData.append("name", name);
        if (imgFile) formData.append("image", imgFile);
        if (statusFlag !== undefined) formData.append("statusFlag", statusFlag ? 1 : 0);
        if (categoryId.length > 0) formData.append("categoryId", JSON.stringify(categoryId));

        formData.append("updateUser", createUser);

        try {
            const res = await axios.put(`http://localhost:1001/api/brand/update/${state?.id}`, formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                    Authorization: `Bearer ${token}`,
                },
            });

            if (res.data.success === 1) {
                setSuccessMessage(res.data.message);
                navigate("/product/brand");
            } else {
                setErrorMessage(res.data.message || "Error updating brand");
            }
        } catch (err) {
            const msg = err?.response?.data?.message || "Error while updating";
            setErrorMessage(msg);
        }

        setTimeout(() => {
            setErrorMessage("");
            setSuccessMessage("");
        }, 3000);
    };


    return (
        <>
            <div className='product-head'>
                <h3>Product List</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className="categroy-description">
                <form onSubmit={handleSubmit}>
                    <div>
                        <label className="category-brand">Brand Name</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="add-category"
                            placeholder="Enter the Brand Name"
                            required
                        />
                    </div>

                    <div>
                        <label className="category-brand">Select Categories</label>
                        <select
                            className="add-category"
                            value={categoryId}
                            onChange={(e) =>
                                setCategoryId(Array.from(e.target.selectedOptions, opt => opt.value))
                            }
                            multiple
                        >
                            {categories.map((cat) => (
                                <option key={cat.id} value={cat.id}>
                                    {cat.name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="category-brand">Status</label>
                        <select
                            className="add-category"
                            value={statusFlag ? "1" : "0"}
                            onChange={(e) => setStatusFlag(e.target.value === "1")}
                        >
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>

                    <div>
                        <label className="category-brand">Brand Image</label>
                        <input
                            type="file"
                            onChange={handleImageChange}
                            className="add-category"
                        />
                        <div className="mt-2">
                            <input
                                type="checkbox"
                                checked={showImg ? true : false}
                                onChange={() => setShowImg(showImg ? null : showImg)}
                            />
                            <label className="ms-2">Show Image Preview</label>
                            {showImg && (
                                <img
                                    src={showImg}
                                    alt="Preview"
                                    className="img-fluid mt-2"
                                    style={{ width: '8rem', height: '8rem', objectFit: 'contain' }}
                                />
                            )}
                        </div>
                    </div>

                    <div className="d-flex justify-content-end mt-3">
                        <button type="submit" className="add-btn">Update</button>
                    </div>

                    {successMessage && <div className="text-success mt-3">{successMessage}</div>}
                    {errorMessage && <div className="text-danger mt-3">{errorMessage}</div>}
                </form>
            </div>
        </>
    );
}