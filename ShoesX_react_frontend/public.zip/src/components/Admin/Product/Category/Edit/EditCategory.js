import { useLocation, useNavigate } from 'react-router-dom';
import '../../../../Assets/scss/category.css';
import React, { useState, useEffect } from "react";
import axios from "axios";

export function EditCategory() {
    const navigate = useNavigate();
    const { state } = useLocation();

    const [Name, setName] = useState(state?.name);
    const [StatusFlag, setStatusFlag] = useState(state?.statusFlag);
    const [errorMessage, setErrorMessage] = useState("");
    const [updateUser, setUpdateUser] = useState("");
    const [token, setToken] = useState("");

    useEffect(() => {
        const tokenFromStorage = localStorage.getItem("token");
        if (!tokenFromStorage) {
            setErrorMessage("Unauthorized: No token found");
            return;
        }

        setToken(tokenFromStorage);
        const decodedToken = JSON.parse(atob(tokenFromStorage.split('.')[1]));
        setUpdateUser(decodedToken?.id);
    }, []);


    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage("");

        try {
            const { data } = await axios.put(
                `http://localhost:1001/api/category/update/${state.id}`,
                {
                    name: Name,
                    updateUser,
                    statusFlag: StatusFlag
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            if (data.success === 1) {
                navigate("/product/category");
            } else {
                setErrorMessage(data.message || "Error updating category");
            }
        } catch (err) {
            const errMsg = err?.response?.data?.message || "Something went wrong.";
            setErrorMessage(errMsg);
        }
    };

    return (
        <>
        <div className='product-head'>
                <h3>Edit Category</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className='categroy-description'>
                <form onSubmit={handleSubmit}>
                    <div className='d-flex'>
                        <div>
                            <label htmlFor='editCategory' className='category-brand'>
                                Category <span className='star'>*</span>
                            </label>
                            <input
                                type="text"
                                id='editCategory'
                                className='add-category'
                                placeholder="Enter The Category Name"
                                value={Name}
                                onChange={(e) => setName(e.target.value)}
                                required
                            />
                        </div>
                    </div>

                    <div>
                        <label className="category-brand">Select Status Flag</label>
                        <select
                            className="add-category"
                            value={StatusFlag ? "1" : "0"}
                            onChange={(e) => setStatusFlag(e.target.value === "1")}
                            required
                        >
                            <option value="1">Active</option>
                            <option value="0">InActive</option>
                        </select>
                    </div>

                    {errorMessage && <div className="text-danger mt-2">{errorMessage}</div>}

                    <div className='d-flex justify-content-end mt-3'>
                        <button type='submit' className='add-btn'>Update</button>
                    </div>
                </form>
            </div>
        </>
    );
}
