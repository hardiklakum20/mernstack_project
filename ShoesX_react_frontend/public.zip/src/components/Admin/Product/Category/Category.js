import { useNavigate } from "react-router-dom";
import '../../../Assets/scss/category.css';
import React, { useState, useEffect } from "react";
import axios from "axios";

export function Category() {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    const token = localStorage.getItem("token");
    if (!token) {
        navigate("/login");
    }

    useEffect(() => {
        const fetchData = async () => {
            try {
                const { data } = await axios.get('http://localhost:1001/api/category', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                if (data?.success === 1) {
                    setData(data.data);
                }
            } catch (err) {
                setErrorMessage(err?.response?.data?.message || "Error fetching data.");
            }
        };

        fetchData();
    }, [token]);

    useEffect(() => {
        if (successMessage || errorMessage) {
            const timer = setTimeout(() => {
                setSuccessMessage("");
                setErrorMessage("");
            }, 3000);

            return () => clearTimeout(timer);
        }
    }, [successMessage, errorMessage]);

    const handleDelete = async (id) => {
        try {
            const { data } = await axios.delete(`http://localhost:1001/api/category/delete/${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (data.success === 1) {
                setSuccessMessage(data?.message);
                setData(prev => prev.filter(item => item.id !== id));
            }
        } catch (err) {
            const errMsg = err?.response?.data?.message;
            setErrorMessage(errMsg || "Error while deleting the category.");
        }
    };

    return (
        <>
            <div className='Category-head d-flex justify-content-between'>
                <p id='category'>Category</p>
                <button id='add-category-btn' onClick={() => navigate('/product/category/add')}>Add Category</button>
            </div>

            <div className='categroy-description body-bg'>
                <div>
                    <input
                        type="text"
                        placeholder="Search Category"
                        className="search-bar"
                        onChange={() => { }}
                    />
                </div>

                <div className="my-2">
                    {successMessage && <div className="text-success">{successMessage}</div>}
                    {errorMessage && <div className="text-danger">{errorMessage}</div>}
                </div>

                <div className="product-table table-responsive-xxl">
                    <table className="table align-middle">
                        <thead>
                            <tr className="text-center">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                                <th>Created By</th>
                                <th>Updated By</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Array.isArray(data) && data.length > 0 ? (
                                data.map((item) => (
                                    <tr key={item.id} className="text-center">
                                        <td>{item.id}</td>
                                        <td>{item.name}</td>
                                        <td>{item.statusFlag ? 'Active' : 'Inactive'}</td>
                                        <td>{new Date(item.createAt).toLocaleString()}</td>
                                        <td>{new Date(item.updateAt).toLocaleString()}</td>
                                        <td>{item.createUser}</td>
                                        <td>{item.updateUser}</td>
                                        <td>
                                            <button
                                                className="btn btn-outline-success"
                                                onClick={() => navigate(`edit`, { state: item })}
                                            >
                                                Edit
                                            </button>
                                            <button
                                                className="btn btn-outline-danger ms-2"
                                                onClick={() => handleDelete(item.id)}
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr className="text-center">
                                    <td colSpan="8">No categories available</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
}