import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../../../../Assets/scss/category.css";

export function AddBrand() {
    const navigate = useNavigate();

    const [showImg, setShowImg] = useState(null);
    const [showPreview, setShowPreview] = useState(true);
    
    const [data, setData] = useState([]);
    const [categoryId, setCategoryId] = useState("");
    const [Name, setName] = useState("");
    const [imgFile, setImgFile] = useState(null);
    const [StatusFlag, setStatusFlag] = useState(true);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    const handleShowImg = (e) => {
        const file = e.target.files[0];
        if (file) {
            setShowImg(URL.createObjectURL(file));
            setImgFile(file);
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            const token = localStorage.getItem("token");
            if (!token) {
                navigate("/login");
                console.warn("No auth token found");
                return;
            }

            try {
                const res = await axios.get("http://localhost:1001/api/category/", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                if (res.data?.success) setData(res.data.data);
            } catch (err) {
                console.error("Error fetching brand data:", err);
            }
        };
        fetchData();
    }, [navigate]);

    const resetForm = () => {
        setName("");
        setImgFile(null);
        setShowImg(null);
        setCategoryId("");
        setStatusFlag(true);
    };

    const clearMessages = () => {
        setSuccessMessage("");
        setErrorMessage("");
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        clearMessages();

        if (!Name || !imgFile) {
            setErrorMessage("Please enter all fields");
            return;
        }

        const token = localStorage.getItem("token");
        if (!token) {
            setErrorMessage("Unauthorized: No token found");
            return;
        }

        const decodedToken = JSON.parse(atob(token.split('.')[1]));
        const createUser = decodedToken?.id;

        if (!createUser) {
            setErrorMessage("User not found in token");
            return;
        }

        const formData = new FormData();
        formData.append("name", Name);
        formData.append("image", imgFile);
        formData.append("createUser", createUser);
        formData.append("statusFlag", StatusFlag ? 1 : 0);
        formData.append("categoryId", parseInt(categoryId));

        try {
            const res = await axios.post(
                "http://localhost:1001/api/brand/create",
                formData,
                {
                    headers: {
                        "Content-Type": "multipart/form-data",
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            if (res.data.success) {
                setSuccessMessage(res.data.message);
                resetForm();
                setTimeout(() => setSuccessMessage(""), 3000);
                navigate("/admin/product/brand");
            } else {
                setErrorMessage(res.data.message || "Error in category creation");
                setTimeout(() => setErrorMessage(""), 3000);
            }
        } catch (err) {
            console.error(err);
            const errMsg = err?.response?.data?.message || "Error while uploading";
            setErrorMessage(errMsg);
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    return (
        <div className="categroy-description">
            <form onSubmit={handleSubmit}>
                <div>
                    <label className="category-brand">Brand</label>
                    <input
                        type="text"
                        placeholder="Enter The Brand Name"
                        value={Name}
                        onChange={(e) => {
                            setName(e.target.value);
                            clearMessages();
                        }}
                        className="add-category"
                        name="brand"
                        required
                    />
                </div>

                <div>
                    <label className="category-brand">Brand Image</label>
                    <input
                        type="file"
                        onChange={handleShowImg}
                        className="add-category"
                        required
                    />
                    <div>
                        <input
                            type="checkbox"
                            checked={showPreview}
                            onChange={() => setShowPreview(!showPreview)}
                        />
                        Show Img
                    </div>
                    {showPreview && showImg && (
                        <img
                            src={showImg}
                            alt="Preview"
                            className="img-fluid mt-2"
                            style={{ width: "8rem", height: "8rem", objectFit: "contain" }}
                        />
                    )}
                </div>

                <div>
                    <label className="category-brand">Select Category</label>
                    <select
                        className="add-category"
                        value={categoryId}
                        onChange={(e) => setCategoryId(e.target.value)}
                        required
                    >
                        <option value="">-- Select a Category --</option>
                        {data.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                                {cat.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="category-brand">Status</label>
                    <div>
                        <input
                            type="checkbox"
                            checked={StatusFlag}
                            onChange={() => setStatusFlag(!StatusFlag)}
                        />
                        <label> Active</label>
                    </div>
                </div>

                <div className="d-flex justify-content-end">
                    <button type="submit" className="add-btn">
                        Add
                    </button>
                </div>

                {successMessage && <div className="text-success">{successMessage}</div>}
                {errorMessage && <div className="text-danger">{errorMessage}</div>}
            </form>
        </div>
    );
}
