import React from 'react'
import { Link } from 'react-router-dom'

function Order() {
    return (
        <>
            <div className='product-head'>
                <h3>Order</h3>
                {/* <Link to={'/admin/product/add-product'}><button className='btn' id='add-category-btn'>Add Product</button></Link> */}
            </div>
            <div className='product-body body-bg'>
            <div className='d-flex align-items-center justify-content-between flex-md-nowrap flex-wrap gap-3 gap-md-4'>
                    <div className='input-div'>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="gray" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="11" cy="11" r="8" />
                            <line x1="16" y1="16" x2="22" y2="22" />
                        </svg>
                        <input placeholder="Search Product" type="text" />
                    </div>
                    <div className='d-flex gap-md-3 gap-2 w-100'> 
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Active</option>
                            <option value="1">Inactive</option>                            
                        </select>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Category</option>
                            <option value="1">Brand</option>                            
                        </select>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Category</option>
                            <option value="1">Brand</option>                            
                        </select>
                    </div>
                </div>
                <div className='product-table table-responsive-xxl'>
                    <table className="table align-middle">
                        <thead className=''>
                            <tr>
                                <th>Order Id</th>
                                <th>User Id</th>
                                <th>SKU</th>
                                <th>Price</th>
                                <th>Color</th>
                                <th>Size</th>
                                <th>Quantity</th>
                                <th>Order Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>#6d30</td>
                                <td>#f276</td>
                                <td>#zara05</td>
                                <td>3599</td>
                                <td>Burgundy</td>
                                <td>L</td>
                                <td>2</td>
                                <td><select className="form-select border-0 shadow-none" aria-label="Default select example">
                                    <option selected>Shippped</option>
                                    <option value="1">Pending</option>
                                    <option value="2">Delivered</option>
                                    <option value="3">Cancel</option>
                                </select></td>
                                <td>
                                    <div className='action'>
                                        <Link className='text-black'><i className="fa-solid fa-eye"></i></Link>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>#6d30</td>
                                <td>#f276</td>
                                <td>#zara05</td>
                                <td>3599</td>
                                <td>Burgundy</td>
                                <td>L</td>
                                <td>2</td>
                                <td><select className="form-select border-0 shadow-none" aria-label="Default select example">
                                    <option selected>Shippped</option>
                                    <option value="1">Pending</option>
                                    <option value="2">Delivered</option>
                                    <option value="3">Cancel</option>
                                </select></td>
                                <td>
                                    <div className='action'>
                                        <Link className='text-black'><i className="fa-solid fa-eye"></i></Link>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>#6d30</td>
                                <td>#f276</td>
                                <td>#zara05</td>
                                <td>3599</td>
                                <td>Burgundy</td>
                                <td>L</td>
                                <td>2</td>
                                <td><select className="form-select border-0 shadow-none" aria-label="Default select example">
                                    <option selected>Shippped</option>
                                    <option value="1">Pending</option>
                                    <option value="2">Delivered</option>
                                    <option value="3">Cancel</option>
                                </select></td>
                                <td>
                                    <div className='action'>
                                        <Link className='text-black'><i className="fa-solid fa-eye"></i></Link>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </>
    )
}

export default Order