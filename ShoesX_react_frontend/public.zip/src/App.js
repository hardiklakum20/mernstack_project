// import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Login } from './components/Admin/Login/login';
import { Admin } from './components/Admin/Admin';
import { Dashboard } from './components/Admin/Dashboard/dashboard';
import Product from './components/Admin/Product/Product';
import AddProduct from './components/Admin/Product/AddProduct';
import ViewProduct from './components/Admin/Product/ViewProduct';
import EditProduct from './components/Admin/Product/EditProduct';
import { Category } from './components/Admin/Product/Category/Category';
import { AddCategory } from './components/Admin/Product/Category/Add/AddCategory';
import { Size } from './components/Admin/Product/Sizes/size';
import Role from './components/Admin/Role/Role';
import AddRole from './components/Admin/Role/AddRole';
import EditRole from './components/Admin/Role/EditRole';
import Order from './components/Admin/Order/Order';
import Profile from './components/Admin/Profile/Profile';
import PaymentPage from './components/Admin/Payment/Payment';
import { Brand } from './components/Admin/Product/Brand/Brand';
import { AddBrand } from './components/Admin/Product/Brand/Add/AddBrand';
import UserPage from './components/Admin/User/UserPage';
import { Color } from './components/Admin/Product/Color/Color';
import { AddColor } from './components/Admin/Product/Color/AddColor';
import { AddSize } from './components/Admin/Product/Sizes/AddSize';
import ProtectedRoute from './components/ProtectedRoute';
import { EditCategory } from './components/Admin/Product/Category/Edit/EditCategory';
import { EditBrand } from './components/Admin/Product/Brand/Edit/EditBrand';
import { EditColor } from './components/Admin/Product/Color/EditColor';
import { EditSize } from './components/Admin/Product/Sizes/EditSize';


function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route
            path='/'
            // element={<Admin/>}
            element={
              <ProtectedRoute>
                <Admin />
              </ProtectedRoute>}
             >
            <Route path='' element={<Dashboard />}></Route>
            <Route path='/product' element={<Product />}></Route>
            <Route path='/product/add-product' element={<AddProduct />}></Route>
            <Route path='/product/view-product' element={<ViewProduct />}></Route>
            <Route path='/product/edit-product' element={<EditProduct />}></Route>
            <Route path='/product/category' element={<Category />}></Route>
            <Route path='/product/category/add' element={<AddCategory />}></Route>
            <Route path='/product/category/edit' element={<EditCategory />}></Route>
            <Route path='/product/size' element={<Size />}></Route>
            <Route path='/product/size/add' element={<AddSize />}></Route>
            <Route path='/product/size/edit' element={<EditSize />}></Route>
            <Route path='/role' element={<Role />}></Route>
            <Route path='/role/add-role' element={<AddRole />}></Route>
            <Route path='/role/edit-role' element={<EditRole />}></Route>
            <Route path='/order' element={<Order />}></Route>
            <Route path='/profile' element={<Profile />}></Route>
            <Route path='/payment' element={<PaymentPage />}></Route>
            <Route path='/product/brand' element={<Brand />}></Route>
            <Route path='/product/brand/add' element={<AddBrand />}></Route>
            <Route path='/product/brand/edit' element={<EditBrand />}></Route>
            <Route path='/user' element={<UserPage />}></Route>
            <Route path='/color' element={<Color />}></Route>
            <Route path='/addColor' element={<AddColor />}></Route>
            <Route path='/editColor' element={<EditColor />}></Route>
          </Route>
          <Route path='/login' element={<Login />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
